CREATE TABLE [dbo].[lastWatchRecipes]
(
    [user_id] [varchar](50) PRIMARY KEY NOT NULL ,
    [recipe_id1] [varchar](50),
    [recipe_id2] [varchar](50),
    [recipe_id3] [varchar](50)
)

