
--DROP TABLE [users]
--DROP TABLE favoriteRecipes
-- DROP TABLE myRecipes
DROP TABLE familyRecipes
